package com.lnd.dao;

import java.sql.SQLException;
import java.util.List;




import com.lnd.model.UserAccount;

public interface UserAccountDao {
	
	public UserAccount getDetail(String userName) throws SQLException;
	
	void save(UserAccount user);
	//void save1(UserAccount user);
	//void save3(UserAccount user);
	void update(String username, UserAccount newUSer) throws SQLException;
	void update1(String username, UserAccount newUSer);
	void update3(String username, UserAccount newUSer);
	//void remove(String userId);

	UserAccount findUser(String userId, String userPass);

	List<UserAccount> allUsers() throws SQLException;
	List<UserAccount> allUsers1() throws SQLException;
	
	

	UserAccount findUser(String userId);


}
