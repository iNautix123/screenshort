package com.lnd.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lnd.dao.ResultDao;
import com.lnd.model.Result;
import com.lnd.model.UserAccount;
import com.lnd.utils.ConnectionFactory;
import com.lnd.utils.DBUtils;
import com.lnd.utils.QueryConstants;

public class ResultDaoImplementation implements ResultDao {

	
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;
	
	
	
	
	
	public List<Result> allUsers() throws SQLException {

		ResultSet rs = null;
		List<Result> foundList = new ArrayList<Result>();
		Result currentUser = null;
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER4);
			rs = preparedStatment.executeQuery();
			while (rs.next()) {
				currentUser = new Result(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4));
				foundList.add(currentUser);
				//System.out.println("123");
			}
		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return foundList;
	}

	
	
	
	
	
	
	
	
	
	
	public List<Result> allUsers1() throws SQLException {

		ResultSet rs = null;
		List<Result> foundList = new ArrayList<Result>();
		Result currentUser = null;
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER_BY_ID1);
			preparedStatment.setString(1,currentUser.getUsername());

			rs = preparedStatment.executeQuery();
			while (rs.next()) {
				currentUser = new Result(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4));
				foundList.add(currentUser);
				//System.out.println("123");
			}
		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return foundList;
	}

	
}
