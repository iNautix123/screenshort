package com.lnd.dao.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lnd.dao.UserAccountDao;
import com.lnd.model.UserAccount;
import com.lnd.utils.ConnectionFactory;
import com.lnd.utils.DBUtils;
import com.lnd.utils.QueryConstants;





public class UserAccountDaoImplementation implements UserAccountDao{

	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;

	public UserAccountDaoImplementation() {
		
		
	}

	
	
	
	@Override
	public void update(String userId, UserAccount newUser) throws SQLException {

		try {
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.UPDATE_USER);

			preparedStatment.setString(1, newUser.getUserName());
			System.out.println(newUser.getUserName());
			
			preparedStatment.setString(2, newUser.getRole());
			System.out.println(newUser.getRole());
			
			preparedStatment.setString(3, newUser.getEmail());
			System.out.println(newUser.getEmail());
			
			preparedStatment.setString(4, newUser.getTenth());
			System.out.println( newUser.getTenth());
			
			preparedStatment.setString(5, newUser.getTwelfth());
			System.out.println( newUser.getTwelfth());
			
			preparedStatment.setString(6, newUser.getGraduation());
			System.out.println(newUser.getGraduation());
			
			preparedStatment.setString(7, newUser.getQuestion());
			System.out.println(newUser.getQuestion());
			
			preparedStatment.setString(8, newUser.getAnswer());
			System.out.println(newUser.getAnswer());
			
			preparedStatment.setString(9, userId);
			 

			// Execute statement.
			int rowsUpdated = preparedStatment.executeUpdate();
System.out.println(rowsUpdated);
			if (rowsUpdated > 0) {
				System.out.println("User " + userId + " was updated successfully!");
				connection.commit();
			}

		} /*catch (SQLException e) {
			System.out.println("SQLException in update() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in update() method");
				e1.printStackTrace();
			}
		}*/ finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
			
		}

	}


	

	
	@Override
	public void update1(String userId, UserAccount newUser) {

		try {
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.UPDATE_USER1);

		/*	preparedStatment.setString(1, newUser.getUserName());
			System.out.println(newUser.getUserName());*/
			
			preparedStatment.setString(1, newUser.getPassword());
			System.out.println(newUser.getRole());
			
			preparedStatment.setString(2,userId);
			System.out.println(newUser.getEmail());
			
			
			 

			// Execute statement.
			int rowsUpdated = preparedStatment.executeUpdate();
System.out.println(rowsUpdated);
			if (rowsUpdated > 0) {
				System.out.println("User " + userId + " was updated successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in update() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in update() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}


	
	@Override
	public void update3(String userId, UserAccount newUser) {

		try {
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.UPDATE_USER);

			preparedStatment.setString(1, newUser.getUserName());
			System.out.println(newUser.getUserName());
			
			preparedStatment.setString(2, newUser.getRole());
			System.out.println(newUser.getRole());
			
			preparedStatment.setString(3, newUser.getEmail());
			System.out.println(newUser.getEmail());
			
			preparedStatment.setString(4, newUser.getTenth());
			System.out.println( newUser.getTenth());
			
			preparedStatment.setString(5, newUser.getTwelfth());
			System.out.println( newUser.getTwelfth());
			
			preparedStatment.setString(6, newUser.getGraduation());
			System.out.println(newUser.getGraduation());
			
			preparedStatment.setString(7, newUser.getQuestion());
			System.out.println(newUser.getQuestion());
			
			preparedStatment.setString(8, newUser.getAnswer());
			System.out.println(newUser.getAnswer());
			
			preparedStatment.setString(9, userId);
			 

			// Execute statement.
			int rowsUpdated = preparedStatment.executeUpdate();
System.out.println(rowsUpdated);
			if (rowsUpdated > 0) {
				System.out.println("User " + userId + " was updated successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in update() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in update() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}


	

	
	@Override
	public void save(UserAccount user) {

		try {
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.INSERT_USER);

			preparedStatment.setString(1, user.getUserName());
			preparedStatment.setString(2, user.getPassword());
			preparedStatment.setString(3, user.getRole());
			preparedStatment.setString(4, user.getEmail());
			preparedStatment.setString(5, user.getTenth());
			preparedStatment.setString(6, user.getTwelfth());
			preparedStatment.setString(7, user.getGraduation());
			preparedStatment.setString(8, user.getQuestion());
			preparedStatment.setString(9, user.getAnswer());

			// Execute statement.
			int rowsInserted = preparedStatment.executeUpdate();

			if (rowsInserted > 0) {
				System.out.println("A new account was saved successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in save() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in save() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public UserAccount findUser(String userId, String userPass) {

		ResultSet rs = null;
		UserAccount found = null;

		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER);
			preparedStatment.setString(1, userId);
			preparedStatment.setString(2, userPass);
			rs = preparedStatment.executeQuery();
			if (rs.next()) {
				found = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
				
			}

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return found;
	}
	
	@Override
	public UserAccount findUser(String userId) {

		ResultSet rs = null;
		UserAccount found = null;

		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER_BY_ID);
			preparedStatment.setString(1, userId);
			rs = preparedStatment.executeQuery();
			if (rs.next()) {
				found = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
			}

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return found;
	}

	@Override
	public List<UserAccount> allUsers() throws SQLException {

		ResultSet rs = null;
		List<UserAccount> foundList = new ArrayList<UserAccount>();
		UserAccount currentUser = null;
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER);
			rs = preparedStatment.executeQuery();
			while (rs.next()) {
				currentUser = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
				foundList.add(currentUser);
				
				//System.out.println("123");
			}
		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return foundList;
	}



	
	public List<UserAccount> allUsers1() throws SQLException {

		ResultSet rs = null;
		List<UserAccount> foundList1 = new ArrayList<UserAccount>();
		UserAccount currentUser1 = null;
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER1);
			rs = preparedStatment.executeQuery();
			while (rs.next()) {
				currentUser1 = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
				foundList1.add(currentUser1);
				//System.out.println("123");
			}
		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return foundList1;
	}


	public UserAccount getDetail(String userName) throws SQLException {

		String strr = "'"+userName+"'";
		String query = "SELECT * FROM xbbnhm2_login WHERE username ="+strr;
		
		ResultSet rs = null;
		UserAccount account = null;
		
		try {
			connection = ConnectionFactory.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
			
			if(rs.next()) {
			
				account = new UserAccount();
				account.setUserName(rs.getString(1));
				account.setPassword(rs.getString(2));
				account.setRole(rs.getString(3));
				account.setEmail(rs.getString(4));
				account.setTenth(rs.getString(5));
				account.setTwelfth(rs.getString(6));
				account.setGraduation(rs.getString(7));
				account.setQuestion(rs.getString(8));
				account.setAnswer(rs.getString(9));
				System.out.println(account);
			}
			

		} finally {
			DBUtils.close(rs);
			DBUtils.close(statement);
			DBUtils.close(connection);
		}
		return account;
	}
	
	
	
	
}

