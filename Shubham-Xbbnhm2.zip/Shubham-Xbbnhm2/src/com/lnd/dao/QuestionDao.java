package com.lnd.dao;

import java.sql.SQLException;
import java.util.List;

import com.lnd.model.Question;
import com.lnd.model.UserAccount;



public interface QuestionDao {

	
	List<Question> allUsers() throws SQLException;
	void save(Question user);
	
	
	

	
}
