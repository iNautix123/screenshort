package com.lnd.dao;

import java.sql.SQLException;
import java.util.List;

import com.lnd.model.Result;


public interface ResultDao {
	
	List<Result> allUsers() throws SQLException;
	List<Result> allUsers1() throws SQLException;

}
