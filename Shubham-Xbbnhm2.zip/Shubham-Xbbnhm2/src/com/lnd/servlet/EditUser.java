package com.lnd.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lnd.dao.UserAccountDao;
import com.lnd.dao.impl.UserAccountDaoImplementation;
import com.lnd.model.UserAccount;

@WebServlet(urlPatterns = { "/editUser" })
public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 4645721142572801101L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();

	public EditUser() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userId = (String) request.getParameter("id");

		UserAccount editUser = null;
		editUser = userDao.findUser(userId);
		HttpSession session = request.getSession(true);
		session.setAttribute("editUser", editUser);
		System.out.println(editUser);
		
		
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/index11.jsp");
		dispatcher.forward(request, response);
		

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}