package com.lnd.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lnd.dao.UserAccountDao;
import com.lnd.dao.impl.UserAccountDaoImplementation;
import com.lnd.model.UserAccount;
import com.lnd.utils.ConnectionFactory;
import com.lnd.utils.DBUtils;

@WebServlet(urlPatterns = { "/doAddUser" })
public class DoAddUser extends HttpServlet {
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;
	private static final long serialVersionUID = 4645721142572801105L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();

	public DoAddUser() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String loginId = (String) request.getParameter("username");
		String passowrd = (String) request.getParameter("password");
		String role = (String) request.getParameter("role");
		String email = (String) request.getParameter("email");
		String tenth = (String) request.getParameter("tenth");
		String twelfth = (String) request.getParameter("twelfth");
		String graduation = (String) request.getParameter("graduation");
		String question = (String) request.getParameter("question");
		String answer = (String) request.getParameter("answer");
		
		
		UserAccount newUser = new UserAccount(loginId, passowrd, role,email,tenth,twelfth,graduation,question,answer);
		String errorString = null;
		

		String regex = "^[a-zA-Z][0-9]{3}$";

		if ( !loginId.matches(regex)) {
			errorString = "Username not in the form of ^[a-zA-Z][0-9]{3}$ ";
			
		}
		
	
		
		
		
		
		
		
		String username=(String) request.getSession().getAttribute("username");
		ResultSet rs = null;
		
		String a=null;

		HttpSession session = request.getSession();
		
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement("select * from xbbnhm2_login where username=? ");
			preparedStatment.setString(1, loginId);
		
			rs = preparedStatment.executeQuery();
	
			if (rs.next()) {
				
				
				System.out.println("user already exist");
				
				
				 a="user already exists,Please Choose another one";
				 
				
				
				
			}
			
			else
			{
				
				
				
			
			
			 a="";
				System.out.println("new user");
				
			}
			session.setAttribute("j", a);

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		

		if (errorString == null) {
			userDao.save(newUser);
			//errorString="Registered Successfully!!!";
		}

		// Store infomation to request attribute, before forward to views.
		request.setAttribute("errorString", errorString);
		request.setAttribute("newUser", newUser);

		// If error, forward to Edit page.
		if (errorString != null) {
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response);
		}

		// If everything nice.
		// Redirect to the product listing page.
		else {
			
			//request.setAttribute("errorString", "Successfully Registered.");	
			response.sendRedirect(request.getContextPath() + "/index.jsp");
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}