package com.lnd.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lnd.dao.QuestionDao;
import com.lnd.dao.impl.QuestionDaoImplementation;
import com.lnd.model.Question;


@WebServlet(urlPatterns = { "/doAddQuestion" })
public class DoAddQuestion extends HttpServlet {
	
	private static final long serialVersionUID = -2954838221694399584L;
	private QuestionDao userDao = new QuestionDaoImplementation();

	public DoAddQuestion() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String question = (String) request.getParameter("question");
		String option1 = (String) request.getParameter("option1");
		String option2 = (String) request.getParameter("option2");
		String option3 = (String) request.getParameter("option3");
		String option4 = (String) request.getParameter("option4");
		String correct = (String) request.getParameter("correct");
		
		
		
		Question newUser = new Question(question,option1,option2,option3,option4,correct);
		String errorString = null;
		System.out.println("-----------------");
		System.out.println(newUser);
		
		System.out.println("-----------------");

		if (question == null  ) {
			errorString = "Please!,Insert the Question";
			
		}
		
	

		if (errorString == null) {
			userDao.save(newUser);
			errorString="Inserted Successfully!!!";
		}

		// Store infomation to request attribute, before forward to views.
		request.setAttribute("e5", errorString);
		request.setAttribute("newUser", newUser);

		// If error, forward to Edit page.
		if (errorString != null) {
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/company_insertQuestions.jsp");
			dispatcher.forward(request, response);
		}

		// If everything nice.
		// Redirect to the product listing page.
		else {
			
			request.setAttribute("e5", "Successfully Registered.");	
			response.sendRedirect(request.getContextPath() + "/company_insertQuestions.jsp");
			
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}