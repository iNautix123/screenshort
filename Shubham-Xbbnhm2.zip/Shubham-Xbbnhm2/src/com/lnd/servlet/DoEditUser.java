package com.lnd.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lnd.dao.UserAccountDao;
import com.lnd.dao.impl.UserAccountDaoImplementation;
import com.lnd.model.UserAccount;

@WebServlet(urlPatterns = { "/doEditUser" })
public class DoEditUser extends HttpServlet {
	private static final long serialVersionUID = 4645721142572801104L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();

	public DoEditUser() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String loginId = (String) request.getParameter("username");
		String password = (String) request.getParameter("password");
		String role = (String) request.getParameter("role");
		String email = (String) request.getParameter("email");
		String tenth = (String) request.getParameter("tenth");
		String twelfth = (String) request.getParameter("twelfth");
		String graduation = (String) request.getParameter("graduation");
		String question = (String) request.getParameter("question");
		String answer = (String) request.getParameter("answer");

		UserAccount editUser = new UserAccount(loginId, password, role, email,
				tenth, twelfth, graduation, question, answer);
		System.out.println(editUser);

		HttpSession session = request.getSession(true);

		String e = null;

		if (loginId == null) {
			e = "Please!,Enter the Details.";

		}

		if (e == null) {

			try {
				userDao.update(loginId, editUser);
				session.setAttribute("checkDetail", userDao.getDetail(loginId));
				session.setAttribute("checkDetail1", userDao.getDetail(loginId));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			// TODO Auto-generated catch block

			e = "Updated Successfully!!!";
		}

		// Store infomation to request attribute, before forward to views.
		request.setAttribute("e", e);
		request.getRequestDispatcher("/index11.jsp").forward(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}