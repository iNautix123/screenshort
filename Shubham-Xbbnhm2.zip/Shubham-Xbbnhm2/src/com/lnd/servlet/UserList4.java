package com.lnd.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lnd.dao.ResultDao;
import com.lnd.dao.impl.ResultDaoImplementation;
import com.lnd.model.Result;


@WebServlet("/userList4")
public class UserList4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
private ResultDao userDao1=new ResultDaoImplementation();

	public UserList4() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String errorString = null;
		List<Result> allUsers = null;
		try {
			allUsers = userDao1.allUsers();

		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		//System.out.println(allUsers);

		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		request.setAttribute("userList4", allUsers);
		System.out.println(allUsers);
		// Forward to /WEB-INF/views/productListView.jsp
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/userListView4.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
