package com.lnd.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lnd.dao.QuestionDao;
import com.lnd.dao.impl.QuestionDaoImplementation;
import com.lnd.model.Question;
import com.lnd.utils.ConnectionFactory;
import com.lnd.utils.DBUtils;


@WebServlet("/userList3")
public class UserList3 extends HttpServlet {
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;
	private static final long serialVersionUID = 1L;
	private QuestionDao userDao = new QuestionDaoImplementation();

	public UserList3() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String errorString = null;
		List<Question> allUsers = null;
		try {
			allUsers = userDao.allUsers();

		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		//System.out.println(allUsers);

		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		session.setAttribute("userList3", allUsers);
		System.out.println(allUsers);
	String tenth=(String) session.getAttribute("tenth");
	String twelfth=(String) session.getAttribute("twelfth");
	String graduation=(String) session.getAttribute("graduation");
	
	int tenth1=Integer.parseInt(tenth);
	int twelfth1=Integer.parseInt(twelfth);
	int graduation1=Integer.parseInt(graduation);
	
	

	
		// Forward to /WEB-INF/views/productListView.jsp
		
		
		String username=(String) request.getSession().getAttribute("username");
		ResultSet rs = null;
		
		String a=null;
		
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement("select * from xbbnhm2_result where username=? ");
			preparedStatment.setString(1, username);
		
			rs = preparedStatment.executeQuery();
	
			if (rs.next()) {
				
				
				System.out.println("user already exist");
				
				
				 a="yes";
				
				
			}
			
			else
			{
				
				
				
			
			
			 a="no";
				System.out.println("new user");
				
			}

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		
		if(a=="yes")
		{
			System.out.println("sorry");
			String message="Sorry,You Can't give the Test!!!";
			session.setAttribute("shubham",message);
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/exist.jsp");
			dispatcher.forward(request, response);
			
			
		}
		else
		{
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/que.jsp");
		dispatcher.forward(request, response);
		}
		
		
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
