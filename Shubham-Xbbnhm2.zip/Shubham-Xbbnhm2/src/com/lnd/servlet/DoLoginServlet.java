package com.lnd.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;















import com.lnd.dao.UserAccountDao;
import com.lnd.dao.impl.UserAccountDaoImplementation;
import com.lnd.model.UserAccount;
import com.lnd.utils.ConnectionFactory;
import com.lnd.utils.DBUtils;
import com.lnd.utils.QueryConstants;

@WebServlet(urlPatterns = { "/validate" })
public class DoLoginServlet extends HttpServlet {
	
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;


	private static final long serialVersionUID = 5590990410746775329L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();

	public DoLoginServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");

		UserAccount user = null;
		boolean hasError = false;
		String errorString = null;

		if (userName == null || password == null || userName.length() == 0 || password.length() == 0) {
			hasError = true;
			errorString = "Required username and password!";
			System.out.println(errorString);
		} else {

			user = userDao.findUser(userName, password);
			if (user == null) {
				hasError = true;
				errorString = "User Name or password invalid";
				System.out.println(errorString);	
				request.setAttribute("errorString", "Unknown login, please try again.");	
			
			
			}

		}
		// If error, forward to /WEB-INF/views/_login.jsp
		if (hasError) {
			user = new UserAccount();
			user.setUserName(userName);
			user.setPassword(password);
			// Store information in request attribute, before forward.
			request.setAttribute("errorString", errorString);
			request.setAttribute("user", user);

			// Forward to /WEB-INF/views/_login.jsp
			getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		}

		// If no error
		// Store user information in Session
		// And redirect to correct home page.
		else {
			HttpSession session = request.getSession(true);
			session.setAttribute("userIs", user);
			session.setAttribute("username",user.getUserName());
			
			if (user.getRole().equals("student")) {
				// Redirect to userInfo page.
				try{
				UserAccountDao Emp=new UserAccountDaoImplementation();
				UserAccountDao Emp1=new UserAccountDaoImplementation();
				UserAccount checkDetail=Emp.getDetail(userName);
				UserAccount checkDetail1=Emp1.getDetail(userName);
//				request.setAttribute("checkDetail",checkDetail);
				  session.setAttribute("checkDetail",checkDetail); 
				  session.setAttribute("checkDetail1",checkDetail1);  
				  String tenth=user.getTenth();
					String twelfth=user.getTwelfth();
					String graduation=user.getGraduation();
					session.setAttribute("tenth",tenth);
					session.setAttribute("twelfth",twelfth);
					session.setAttribute("graduation",graduation);
				  


				}
				catch(SQLException e)
				{System.out.println(e.getMessage());}
				getServletContext().getRequestDispatcher("/index11.jsp").forward(request, response);
				
			}
			
		
			
			else if (user.getRole().equals("company")) {
				
				try{
					UserAccountDao Emp2=new UserAccountDaoImplementation();
					UserAccountDao Emp3=new UserAccountDaoImplementation();
					UserAccount checkDetail2=Emp2.getDetail(userName);
					UserAccount checkDetail3=Emp3.getDetail(userName);
//					request.setAttribute("checkDetail",checkDetail);
					  session.setAttribute("checkDetail",checkDetail2); 
					  session.setAttribute("checkDetail1",checkDetail3); 
					}
					catch(SQLException e)
					{System.out.println(e.getMessage());}
				
			
				
				getServletContext().getRequestDispatcher("/company_viewProfile.jsp").forward(request, response);
			}
			
			else
			{
				
				getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
			
				
			}
		}
		
		/*ResultSet rs = null;
	

		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement("select * from xbbnhm2_result where username=?");
			preparedStatment.setString(1, userName);
		
			rs = preparedStatment.executeQuery();
			if (rs.next()) {
				System.out.println("user already exist");
				String a="yes";
				
			}
			
			else
			{
				String a="no";
				System.out.println("new user");
				
			}

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
*/

		/*ResultSet rs1 = null;
		HttpSession session = request.getSession(true);
		
String message=null;
		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement("select * from xbbnhm2_login where (tenth<60 and twelfth<60 and graduation<60) and username=?");
			preparedStatment.setString(1, userName);
		
			rs1 = preparedStatment.executeQuery();
			if (rs1.next()) {
				message="You are not Eligible For the Test!!!";
				System.out.println(message);
				
				
			}
			
			
			else
			{
				
			session.setAttribute("tenth",user.getTenth());
			session.setAttribute("twelfth",user.getTwelfth());
			session.setAttribute("graduation",user.getGraduation());
			
				int a=Integer.parseInt(user.getTenth());
				int b=Integer.parseInt(user.getTwelfth());
				int c=Integer.parseInt(user.getGraduation());
				if( a>=60 && b>=60 && c>=60)
				{
					message="Eligible";
					System.out.println(message);
					
				}
				else
				{
					message="You are not Eligible For the Test!!!";
					System.out.println(message);
					
					
					
				}
				
				
			}
			session.setAttribute("vohra",message );

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

*/
		
		
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}





































/*package com.carparking.servlet;
 * 

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.carparking.dao1.UserAccountDao;
import com.carparking.dao.implementation.UserAccountDaoImplementation;
import com.carparking.model.UserAccount;

@WebServlet("/dologin")
public class DoLoginServlet extends HttpServlet {

	*//**
	 * 
	 *//*
	private static final long serialVersionUID = 491357214476002160L;

	public DoLoginServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		String user = request.getParameter("userName");
		String pass = request.getParameter("password");
		String role = request.getParameter("role");
		UserAccountDao empDao = new UserAccountDaoImplementation();
		
		try {
			UserAccount regEmp = empDao.get(user);
			
			if(regEmp != null){
				System.out.println(regEmp.getPassword());
				
				if (regEmp.getPassword().equals(pass)){
					System.out.println("dsadsa");
					HttpSession sessionEmp = request.getSession(true);
					sessionEmp.setAttribute("userId", regEmp.getUserName());
					getServletContext().getRequestDispatcher(
							"/WEB-INF/views/index11.jsp").forward(request,
							response);
				}
			}
			else {
				String msg = "Incorrect Password";
				System.out.println(msg);
				request.setAttribute("passError", msg);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/views/index.jsp").forward(request,
						response);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			String msg = "Incorrect Id or Password";
			System.out.println(msg);
			request.setAttribute("IdError", msg);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/views/index.jsp").forward(request,
					response);


		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
*/