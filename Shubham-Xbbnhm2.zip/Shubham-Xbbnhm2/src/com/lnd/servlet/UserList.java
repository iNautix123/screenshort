package com.lnd.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lnd.dao.UserAccountDao;
import com.lnd.dao.impl.UserAccountDaoImplementation;
import com.lnd.model.UserAccount;

@WebServlet("/userList")
public class UserList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserAccountDao userDao = new UserAccountDaoImplementation();

	public UserList() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String errorString = null;
		List<UserAccount> allUsers = null;
		HttpSession session = request.getSession(true);
		
		try {
			allUsers = userDao.allUsers();
	

		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		
		//System.out.println(allUsers);

		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		request.setAttribute("userList", allUsers);
		System.out.println(allUsers);
		String tenth=(String) session.getAttribute("tenth");
		int tenth1=Integer.parseInt(tenth);
		
		String twelfth=(String) session.getAttribute("twelfth");
		int twelfth1=Integer.parseInt(twelfth);
		
		String graduation=(String) session.getAttribute("graduation");
		int graduation1=Integer.parseInt(graduation);
		
		if(tenth1>=60 && twelfth1>=60 && graduation1>=60)
		{
			
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/userListView.jsp");
			dispatcher.forward(request, response);
		}
			
		else
		{
			
			
			String message="You are not Eligible for any company!!!";
			
			session.setAttribute("c", message);
			
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/noteligible.jsp");
			dispatcher.forward(request, response);
			
			
		}
			
			
		}
		
		
		// Forward to /WEB-INF/views/productListView.jsp
		

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
