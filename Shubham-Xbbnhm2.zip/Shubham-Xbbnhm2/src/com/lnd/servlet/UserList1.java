package com.lnd.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lnd.dao.UserAccountDao;
import com.lnd.dao.impl.UserAccountDaoImplementation;
import com.lnd.model.UserAccount;

@WebServlet("/userList1")
public class UserList1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserAccountDao userDao1 = new UserAccountDaoImplementation();

	public UserList1() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String errorString = null;
		List<UserAccount> allUsers1 = null;
		try {
			allUsers1 = userDao1.allUsers1();

		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		//System.out.println(allUsers);

		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		request.setAttribute("userList1", allUsers1);
		System.out.println(allUsers1);
		// Forward to /WEB-INF/views/productListView.jsp
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/userListView1.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
