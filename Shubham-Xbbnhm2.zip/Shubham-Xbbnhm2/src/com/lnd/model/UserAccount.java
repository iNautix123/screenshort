package com.lnd.model;

public class UserAccount {
	
	private String userName;
	private String password;
	private String role;
	private String email;
	private String tenth;
	private String twelfth;
	private String graduation;
	private String question;
	private String answer;
	
	
	

	public UserAccount() {
		// TODO Auto-generated constructor stub
	}

	public UserAccount(String userName,String password,String role,String email,String tenth,String twelfth,String graduation,String question,String answer ) {
		// TODO Auto-generated constructor stub
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
		this.email=email;
		this.tenth=tenth;
		this.twelfth=twelfth;
		this.graduation=graduation;
		this.question=question;
		this.answer=answer;
		
		
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTenth() {
		return tenth;
	}

	public void setTenth(String tenth) {
		this.tenth = tenth;
	}

	public String getTwelfth() {
		return twelfth;
	}

	public void setTwelfth(String twelfth) {
		this.twelfth = twelfth;
	}

	public String getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	
	
	

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "UserAccount [userName=" + userName + ", password=" + password
				+ ", role=" + role + ", email=" + email + ", tenth=" + tenth
				+ ", twelfth=" + twelfth + ", graduation=" + graduation
				+ ", question=" + question + ", answer=" + answer + "]";
	}

	
	
	
	
	
	
	


	

}
