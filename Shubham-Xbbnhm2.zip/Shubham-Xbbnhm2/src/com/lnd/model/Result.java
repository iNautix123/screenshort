package com.lnd.model;

public class Result {

	private String username;
	private String marks;
	private String percentage;
	private String status;

	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Result(String username, String marks, String percentage,
			String status) {
		super();
		this.username = username;
		this.marks = marks;
		this.percentage = percentage;
		this.status = status;

	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the marks
	 */
	public String getMarks() {
		return marks;
	}
	/**
	 * @param marks the marks to set
	 */
	public void setMarks(String marks) {
		this.marks = marks;
	}
	/**
	 * @return the percentage
	 */
	public String getPercentage() {
		return percentage;
	}
	/**
	 * @param percentage the percentage to set
	 */
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the selected
	 */
	
	
	
	
	
	
	
}
