package com.lnd.utils;

public class QueryConstants {
	public static final String INSERT_USER = "INSERT INTO xbbnhm2_login VALUES(?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_USER1 = "INSERT INTO que_xbb VALUES(?,?,?,?,?,?)";
	public static final String UPDATE_USER1 = "UPDATE xbbnhm2_login SET password=? WHERE username=?";
    public static final String UPDATE_USER = "UPDATE xbbnhm2_login SET username=?,role=?,email=?,tenth=?,twelfth=?,graduation=?,question=?,answer=? WHERE username=?";
	//public static final String DELETE_USER= "DELETE FROM GD_LOGIN WHERE LOGIN_ID=?";
	public static final String SELECT_USER = "SELECT * FROM xbbnhm2_login WHERE username=? AND password=?";
	public static final String SELECT_USER_BY_ID = "SELECT * FROM xbbnhm2_login	 WHERE username=?";
	public static final String SELECT_ALL_USER = "SELECT * FROM xbbnhm2_login where role='company' and (tenth>=60 and twelfth>=60 and graduation>=60) ";//ORDER BY role
	public static final String SELECT_ALL_USER1 = "SELECT * FROM xbbnhm2_login where role='student' and (tenth>=60 and twelfth>=60 and graduation>=60) ";//ORDER BY role
	public static final String SELECT_ALL_USER3 = "SELECT * FROM que_xbb";//ORDER BY role
	public static final String SELECT_ALL_USER4 = "SELECT * FROM xbbnhm2_result where result='passed'";//ORDER BY role
	public static final String SELECT_USER_BY_ID1 = "SELECT * FROM xbbnhm2_result	 WHERE username=?";
}


//SELECT * FROM GD_ACCOUNT;
//
//DROP TABLE GD_LOGIN;
//CREATE TABLE GD_LOGIN
//(
//  LOGIN_ID VARCHAR(200),
//  PASSWORD VARCHAR(200),
//  ROLE VARCHAR2(20)
//);
//
//INSERT INTO GD_LOGIN VALUES('N001','123','normal');
//INSERT INTO GD_LOGIN VALUES('N002','123','normal');
//INSERT INTO GD_LOGIN VALUES('N003','123','normal');
//INSERT INTO GD_LOGIN VALUES('N004','123','normal');
//INSERT INTO GD_LOGIN VALUES('N005','123','normal');
//
//INSERT INTO GD_LOGIN VALUES('A001','123','admin');
//INSERT INTO GD_LOGIN VALUES('A002','123','admin');
//INSERT INTO GD_LOGIN VALUES('A003','123','admin');
//INSERT INTO GD_LOGIN VALUES('A004','123','admin');
//INSERT INTO GD_LOGIN VALUES('A005','123','admin');
//
//COMMIT;
//SELECT * FROM GD_Login;