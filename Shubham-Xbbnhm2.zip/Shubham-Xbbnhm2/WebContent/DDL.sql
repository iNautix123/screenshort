






desc xbbnhm2_login;
drop table xbbnhm2_login;
create table xbbnhm2_login(username varchar2(50),password varchar2(50),role varchar2(50),email varchar2(50),tenth varchar2(50),twelfth varchar2(50),graduation varchar2(50),question varchar2(50),answer varchar2(50));
select * from xbbnhm2_login;

delete from xbbnhm2_login where username='s123';
ALTER TABLE xbbnhm2_login
ADD CONSTRAINT MyUniqueConstraint UNIQUE(username);
commit;

desc que_xbb;
drop table que_xbb;
create table que_xbb(question varchar2(200),option1 varchar2(200),option2 varchar2(200),option3 varchar2(200),option4 varchar2(200),correct_ans varchar2(50));
select * from que_xbb;
DELETE FROM QUE_XBB;

desc xbbnhm2_result;
drop table xbbnhm2_result;
create table xbbnhm2_result(username varchar2(50),total int,percentage int,result varchar2(50));
select * from xbbnhm2_result;

commit;










